// Powered by OnSpace.AI
// Real auth service backed by Supabase. Registration uses email OTP
// verification, then charges the platform's mandatory onboarding fee
// through the active payment gateway (mock or Paymob — see
// services/paymentGateway) and records it in the payments table.
import { getSupabaseClient } from '@/template';
import { paymentGateway } from './paymentGateway';
import { validateCard } from './paymentService';
import { APP_CONFIG } from '@/constants/config';
import type { CardInput, User } from './types';

const supabase = getSupabaseClient();

export type AuthResult = { success: true; user: User } | { success: false; error: string };
export type RegistrationCharge =
  | { success: true; mode: 'instant' }
  | { success: true; mode: 'checkout'; checkoutUrl: string; paymentId: string }
  | { success: false; error: string };

// Suppress the auth-change listener while a multi-step registration is running
// so the app does not navigate away before the profile + fee are persisted.
let suppressAuthEvents = false;

function friendly(message: string): string {
  const m = (message || '').toLowerCase();
  if (m.includes('invalid login')) return 'Invalid email or password.';
  if (m.includes('expired')) return 'The code has expired. Please request a new one.';
  if (m.includes('token') || (m.includes('invalid') && m.includes('otp')))
    return 'Invalid or incorrect verification code.';
  if (m.includes('already registered') || m.includes('already exists'))
    return 'An account with this email already exists.';
  if (m.includes('rate limit') || m.includes('too many'))
    return 'Too many attempts. Please wait a moment and try again.';
  return message || 'Something went wrong. Please try again.';
}

async function buildUser(authUser: { id: string; email?: string | null; created_at?: string; user_metadata?: Record<string, any> }): Promise<User> {
  const { data: profile } = await supabase
    .from('user_profiles')
    .select('full_name, phone, card_last4, email, created_at')
    .eq('id', authUser.id)
    .maybeSingle();

  const meta = authUser.user_metadata ?? {};
  return {
    id: authUser.id,
    email: authUser.email ?? profile?.email ?? '',
    fullName: profile?.full_name || meta.full_name || meta.username || '',
    phone: profile?.phone || meta.phone || '',
    role: 'customer',
    createdAt: authUser.created_at ?? profile?.created_at ?? new Date().toISOString(),
    cardLast4: profile?.card_last4 || undefined,
  };
}

export async function getCurrentUser(): Promise<User | null> {
  const {
    data: { session },
  } = await supabase.auth.getSession();
  if (!session?.user) return null;
  return buildUser(session.user);
}

export function subscribeToAuth(callback: (user: User | null) => void): () => void {
  const { data } = supabase.auth.onAuthStateChange(async (_event, session) => {
    if (suppressAuthEvents) return;
    if (session?.user) {
      const user = await buildUser(session.user);
      if (!suppressAuthEvents) callback(user);
    } else {
      callback(null);
    }
  });
  return () => data.subscription.unsubscribe();
}

// Step 1 of registration: send a one-time verification code to the email.
export async function sendRegistrationOtp(email: string): Promise<{ error: string | null }> {
  const { error } = await supabase.auth.signInWithOtp({
    email: email.trim(),
    options: { shouldCreateUser: true },
  });
  return { error: error ? friendly(error.message) : null };
}

// Step 2 of registration: verify the code, set a password and complete the
// profile. Returns the signed-in user; the caller (register.tsx) then
// separately triggers the onboarding-fee charge via `chargeRegistrationFee`
// so the UI can show a Paymob checkout sheet if needed.
export async function completeRegistration(params: {
  fullName: string;
  email: string;
  phone: string;
  password: string;
  otp: string;
}): Promise<AuthResult> {
  const { fullName, email, phone, password, otp } = params;

  suppressAuthEvents = true;
  try {
    const { data: verifyData, error: verifyError } = await supabase.auth.verifyOtp({
      email: email.trim(),
      token: otp.trim(),
      type: 'email',
    });
    if (verifyError || !verifyData.session || !verifyData.user) {
      return {
        success: false,
        error: verifyError ? friendly(verifyError.message) : 'Verification failed. Please try again.',
      };
    }

    const authUser = verifyData.user;

    const { error: updateError } = await supabase.auth.updateUser({
      password,
      data: { full_name: fullName, phone, username: fullName },
    });
    if (updateError) console.log('updateUser error:', updateError.message);

    const { error: profileError } = await supabase
      .from('user_profiles')
      .update({ full_name: fullName, phone })
      .eq('id', authUser.id);
    if (profileError) console.log('profile update error:', profileError.message);

    const user = await buildUser({
      id: authUser.id,
      email: authUser.email,
      created_at: authUser.created_at,
      user_metadata: { full_name: fullName, phone, username: fullName },
    });
    return { success: true, user };
  } catch (e) {
    return { success: false, error: friendly((e as Error).message) };
  } finally {
    suppressAuthEvents = false;
  }
}

/** Charges the mandatory onboarding fee for a freshly-created account.
 * With the mock gateway this resolves instantly and also updates the
 * user's stored card_last4. With Paymob it returns a checkout URL for the
 * caller to open in a WebView; card_last4 gets filled in later by the
 * webhook via the payments row (see profile screen for payment history). */
export async function chargeRegistrationFee(params: {
  user: User;
  card?: CardInput;
}): Promise<RegistrationCharge> {
  if (APP_CONFIG.paymentProvider === 'mock') {
    if (!params.card) return { success: false, error: 'Card details are required.' };
    const cardError = validateCard(params.card);
    if (cardError) return { success: false, error: cardError };
  }

  const result = await paymentGateway.charge({
    userId: params.user.id,
    amountEgp: APP_CONFIG.registrationFee,
    kind: 'registration_fee',
    card: params.card,
    customer: { fullName: params.user.fullName, email: params.user.email, phone: params.user.phone },
  });

  if (!result.success) return { success: false, error: result.error };

  if (result.mode === 'instant') {
    await supabase.from('user_profiles').update({ card_last4: result.cardLast4 }).eq('id', params.user.id);
    return { success: true, mode: 'instant' };
  }
  return { success: true, mode: 'checkout', checkoutUrl: result.checkoutUrl, paymentId: result.paymentId };
}

export async function login(email: string, password: string): Promise<AuthResult> {
  const { data, error } = await supabase.auth.signInWithPassword({
    email: email.trim(),
    password,
  });
  if (error || !data.user) {
    return { success: false, error: error ? friendly(error.message) : 'Login failed.' };
  }
  const user = await buildUser(data.user);
  return { success: true, user };
}

export async function logout(): Promise<void> {
  await supabase.auth.signOut();
}
