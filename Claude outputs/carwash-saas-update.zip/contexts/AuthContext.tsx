// Powered by OnSpace.AI
// Global auth state backed by Supabase. Provider only (consumed via hooks/useAuth).
import React, { createContext, useCallback, useEffect, useState, type ReactNode } from 'react';
import * as authService from '@/services/authService';
import type { AuthResult, RegistrationCharge } from '@/services/authService';
import type { CardInput, User } from '@/services/types';

type RegisterParams = {
  fullName: string;
  email: string;
  phone: string;
  password: string;
  otp: string;
};

type AuthContextType = {
  user: User | null;
  initializing: boolean;
  sendRegistrationOtp: (email: string) => Promise<{ error: string | null }>;
  completeRegistration: (params: RegisterParams) => Promise<AuthResult>;
  chargeRegistrationFee: (card?: CardInput) => Promise<RegistrationCharge>;
  login: (email: string, password: string) => Promise<AuthResult>;
  logout: () => Promise<void>;
};

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [initializing, setInitializing] = useState(true);

  useEffect(() => {
    let mounted = true;

    authService.getCurrentUser().then((current) => {
      if (!mounted) return;
      setUser(current);
      setInitializing(false);
    });

    // Keep state in sync with session changes (login, logout, token refresh).
    const unsubscribe = authService.subscribeToAuth((next) => {
      if (mounted) setUser(next);
    });

    return () => {
      mounted = false;
      unsubscribe();
    };
  }, []);

  const sendRegistrationOtp = useCallback(
    (email: string) => authService.sendRegistrationOtp(email),
    [],
  );

  const completeRegistration = useCallback(async (params: RegisterParams) => {
    const result = await authService.completeRegistration(params);
    if (result.success) setUser(result.user);
    return result;
  }, []);

  const chargeRegistrationFee = useCallback(
    async (card?: CardInput) => {
      if (!user) return { success: false as const, error: 'Not signed in.' };
      return authService.chargeRegistrationFee({ user, card });
    },
    [user],
  );

  const login = useCallback(async (email: string, password: string) => {
    const result = await authService.login(email, password);
    if (result.success) setUser(result.user);
    return result;
  }, []);

  const logout = useCallback(async () => {
    await authService.logout();
    setUser(null);
  }, []);

  return (
    <AuthContext.Provider
      value={{ user, initializing, sendRegistrationOtp, completeRegistration, chargeRegistrationFee, login, logout }}
    >
      {children}
    </AuthContext.Provider>
  );
}
