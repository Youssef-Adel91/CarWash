// Powered by OnSpace.AI
import React from 'react';
import { Dimensions, Pressable, StyleSheet, Text, View } from 'react-native';
import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Button } from '@/components/ui/Button';
import { colors, spacing, fontSize, fontWeight } from '@/constants/theme';
import { APP_CONFIG } from '@/constants/config';

export default function Onboarding() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { height } = Dimensions.get('window');

  return (
    <View style={styles.container}>
      <Image
        source={require('@/assets/images/onboarding.png')}
        style={[styles.hero, { height: Math.max(320, height * 0.62) }]}
        contentFit="cover"
        transition={250}
      />
      <LinearGradient
        colors={['transparent', 'rgba(240,247,251,0.7)', colors.background]}
        style={[styles.fade, { height: Math.max(320, height * 0.62) }]}
      />

      <View style={[styles.content, { paddingBottom: insets.bottom + spacing.lg }]}>
        <View style={styles.brandRow}>
          <MaterialCommunityIcons name="car-wash" size={26} color={colors.primary} />
          <Text style={styles.brand}>{APP_CONFIG.name}</Text>
        </View>
        <Text style={styles.title}>Your car wash,{'\n'}right where you park</Text>
        <Text style={styles.subtitle}>
          Request a professional wash from your location. A pro comes to your building and gets it
          sparkling clean.
        </Text>

        <View style={styles.actions}>
          <Button title="Create account" icon="account-plus" onPress={() => router.push('/(auth)/register')} />
          <Button title="I already have an account" variant="ghost" onPress={() => router.push('/(auth)/login')} />
          <Pressable onPress={() => router.push('/(auth)/register-business')} style={styles.businessLink} hitSlop={8}>
            <MaterialCommunityIcons name="store-plus-outline" size={16} color={colors.primaryDark} />
            <Text style={styles.businessText}>I own a car wash business — list it on {APP_CONFIG.name}</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  hero: { width: '100%' },
  fade: { position: 'absolute', top: 0, left: 0, right: 0 },
  content: { flex: 1, justifyContent: 'flex-end', paddingHorizontal: spacing.lg, gap: spacing.sm },
  brandRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  brand: { fontSize: fontSize.bodyLg, fontWeight: fontWeight.bold, color: colors.primaryDark },
  title: { fontSize: fontSize.hero, fontWeight: fontWeight.bold, color: colors.text, lineHeight: 38 },
  subtitle: { fontSize: fontSize.body, color: colors.textSubtle, lineHeight: 24, marginTop: spacing.xs },
  actions: { gap: spacing.sm, marginTop: spacing.lg },
  businessLink: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: spacing.sm },
  businessText: { fontSize: fontSize.caption, color: colors.primaryDark, fontWeight: fontWeight.semibold },
});
