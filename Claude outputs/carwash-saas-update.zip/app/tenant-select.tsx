// Powered by OnSpace.AI
// Customer picks which car-wash company (tenant) to order from. This is
// the SaaS marketplace entry point — every wash type, price and worker a
// customer sees afterwards belongs to this one tenant.
import React, { useCallback, useEffect, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Card } from '@/components/ui/Card';
import { useTenant } from '@/contexts/TenantContext';
import { useAuth } from '@/hooks/useAuth';
import { listActiveTenants } from '@/services/tenantService';
import { colors, spacing, radius, fontSize, fontWeight, shadow } from '@/constants/theme';
import { APP_CONFIG } from '@/constants/config';
import type { Tenant } from '@/services/types';

export default function TenantSelect() {
  const insets = useSafeAreaInsets();
  const { selectTenant } = useTenant();
  const { logout } = useAuth();
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  const load = useCallback(async (q?: string) => {
    setLoading(true);
    try {
      setTenants(await listActiveTenants(q));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return (
    <View style={[styles.container, { paddingTop: insets.top + spacing.md }]}>
      <View style={styles.headerRow}>
        <View style={styles.flex}>
          <Text style={styles.title}>Choose a car wash</Text>
          <Text style={styles.subtitle}>Pick the company you want to order {APP_CONFIG.name} washes from.</Text>
        </View>
        <Pressable onPress={logout} hitSlop={10}>
          <MaterialCommunityIcons name="logout" size={22} color={colors.textMuted} />
        </Pressable>
      </View>

      <View style={styles.searchField}>
        <MaterialCommunityIcons name="magnify" size={20} color={colors.textMuted} />
        <TextInput
          value={search}
          onChangeText={(v) => {
            setSearch(v);
            load(v);
          }}
          placeholder="Search by name…"
          placeholderTextColor={colors.textMuted}
          style={styles.searchInput}
        />
      </View>

      {!loading && tenants.length === 0 ? (
        <View style={styles.empty}>
          <MaterialCommunityIcons name="store-search-outline" size={48} color={colors.textMuted} />
          <Text style={styles.emptyText}>No active car wash companies yet.</Text>
        </View>
      ) : (
        <FlatList
          data={tenants}
          keyExtractor={(t) => t.id}
          contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + spacing.xl }]}
          renderItem={({ item }) => (
            <Pressable onPress={() => selectTenant(item.id)}>
              <Card style={styles.tenantCard}>
                <View style={styles.tenantIcon}>
                  <MaterialCommunityIcons name="car-wash" size={24} color={colors.primary} />
                </View>
                <View style={styles.flex}>
                  <Text style={styles.tenantName}>{item.name}</Text>
                  {item.city ? <Text style={styles.tenantCity}>{item.city}</Text> : null}
                </View>
                <MaterialCommunityIcons name="chevron-right" size={22} color={colors.textMuted} />
              </Card>
            </Pressable>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, paddingHorizontal: spacing.md },
  flex: { flex: 1 },
  headerRow: { flexDirection: 'row', alignItems: 'flex-start', gap: spacing.sm },
  title: { fontSize: fontSize.title, fontWeight: fontWeight.bold, color: colors.text },
  subtitle: { fontSize: fontSize.caption, color: colors.textSubtle, marginTop: 2 },
  searchField: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    height: 48,
    marginTop: spacing.md,
  },
  searchInput: { flex: 1, fontSize: fontSize.body, color: colors.text },
  list: { gap: spacing.sm, marginTop: spacing.md },
  tenantCard: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, ...shadow.soft },
  tenantIcon: {
    width: 44,
    height: 44,
    borderRadius: radius.md,
    backgroundColor: colors.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tenantName: { fontSize: fontSize.body, fontWeight: fontWeight.semibold, color: colors.text },
  tenantCity: { fontSize: fontSize.caption, color: colors.textSubtle, marginTop: 2 },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: spacing.sm },
  emptyText: { color: colors.textSubtle, fontSize: fontSize.body },
});
