// Powered by OnSpace.AI
import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { LiveMap } from '@/components/feature/LiveMap';
import { WashTypeCard } from '@/components/feature/WashTypeCard';
import { Button } from '@/components/ui/Button';
import { useAuth } from '@/hooks/useAuth';
import { useOrders } from '@/hooks/useOrders';
import { useLocation } from '@/hooks/useLocation';
import { useWashTypes } from '@/hooks/useWashTypes';
import { useTenant } from '@/contexts/TenantContext';
import { useAlert } from '@/template';
import { colors, gradients, spacing, radius, fontSize, fontWeight, shadow } from '@/constants/theme';
import { APP_CONFIG } from '@/constants/config';

type ScheduleMode = 'now' | 'later';

export default function Home() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { placeOrder } = useOrders();
  const { selectedTenant, clearSelectedTenant } = useTenant();
  const { washTypes } = useWashTypes();
  const { location, detecting, detect, setLocation } = useLocation();
  const { showAlert } = useAlert();

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [schedule, setSchedule] = useState<ScheduleMode>('now');
  const [placing, setPlacing] = useState(false);

  const selectedWash = useMemo(
    () => washTypes.find((w) => w.id === selectedId) ?? null,
    [selectedId, washTypes],
  );

  const firstName = user?.fullName?.split(' ')[0] ?? 'there';

  const onSwitchCompany = () => {
    showAlert('Switch car wash', 'Pick a different company to order from?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Switch', onPress: () => clearSelectedTenant() },
    ]);
  };

  const onRequest = async () => {
    if (!selectedWash) {
      showAlert('Choose a wash', 'Please select a wash type to continue.');
      return;
    }
    setPlacing(true);
    const scheduledFor =
      schedule === 'later' ? new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString() : null;
    const order = await placeOrder({
      washType: { id: selectedWash.id, name: selectedWash.name, priceEgp: selectedWash.priceEgp },
      location,
      scheduledFor,
    });
    setPlacing(false);
    if (order) router.push(`/order/${order.id}`);
  };

  return (
    <View style={styles.container}>
      <ScrollView
        style={styles.flex}
        contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 120 }]}
        showsVerticalScrollIndicator={false}
      >
        <LinearGradient colors={gradients.hero} style={[styles.hero, { paddingTop: insets.top + spacing.lg }]}>
          <Text style={styles.heroHello}>Hello, {firstName}</Text>
          <Text style={styles.heroTitle}>Book a wash at your doorstep</Text>
          <Pressable onPress={onSwitchCompany} style={styles.tenantBadge} hitSlop={6}>
            <MaterialCommunityIcons name="store-outline" size={14} color="#fff" />
            <Text style={styles.tenantBadgeText} numberOfLines={1}>
              {selectedTenant?.name ?? APP_CONFIG.name}
            </Text>
            <MaterialCommunityIcons name="chevron-down" size={14} color="#fff" />
          </Pressable>
          <View style={styles.heroBadge}>
            <MaterialCommunityIcons name="map-marker-radius" size={16} color="#fff" />
            <Text style={styles.heroBadgeText} numberOfLines={1}>
              {location.address}
            </Text>
          </View>
        </LinearGradient>

        <View style={styles.body}>
          <View style={styles.sectionHead}>
            <Text style={styles.sectionTitle}>Confirm your location</Text>
            <Pressable onPress={detect} style={styles.detectBtn} hitSlop={8}>
              <MaterialCommunityIcons
                name={detecting ? 'loading' : 'crosshairs-gps'}
                size={16}
                color={colors.primary}
              />
              <Text style={styles.detectText}>{detecting ? 'Locating…' : 'Use GPS'}</Text>
            </Pressable>
          </View>

          <LiveMap
            height={200}
            interactive
            center={location}
            onPinMove={(coord) => setLocation({ ...coord, address: 'Pinned location' })}
          />
          <View style={styles.addressRow}>
            <MaterialCommunityIcons name="map-marker" size={18} color={colors.primary} />
            <Text style={styles.address}>{location.address}</Text>
            <Text style={styles.tapHint}>Tap map to adjust pin</Text>
          </View>

          <Text style={[styles.sectionTitle, { marginTop: spacing.md }]}>Choose a wash</Text>
          <View style={styles.washList}>
            {washTypes.map((wash) => (
              <WashTypeCard
                key={wash.id}
                wash={wash}
                selected={selectedId === wash.id}
                onPress={() => setSelectedId(wash.id)}
              />
            ))}
          </View>

          <Text style={[styles.sectionTitle, { marginTop: spacing.md }]}>When?</Text>
          <View style={styles.segment}>
            {(['now', 'later'] as ScheduleMode[]).map((mode) => {
              const active = schedule === mode;
              return (
                <Pressable
                  key={mode}
                  onPress={() => setSchedule(mode)}
                  style={[styles.segmentItem, active && styles.segmentItemActive]}
                >
                  <MaterialCommunityIcons
                    name={mode === 'now' ? 'flash' : 'clock-outline'}
                    size={18}
                    color={active ? colors.textOnPrimary : colors.textSubtle}
                  />
                  <Text style={[styles.segmentText, active && styles.segmentTextActive]}>
                    {mode === 'now' ? 'Wash now' : 'Schedule (+2h)'}
                  </Text>
                </Pressable>
              );
            })}
          </View>
        </View>
      </ScrollView>

      <View style={[styles.footer, { paddingBottom: insets.bottom + spacing.sm }]}>
        <View style={styles.summary}>
          <Text style={styles.summaryLabel}>{selectedWash ? selectedWash.name : 'Total'}</Text>
          <Text style={styles.summaryPrice}>
            {selectedWash ? selectedWash.priceEgp : 0} {APP_CONFIG.currency}
          </Text>
        </View>
        <View style={styles.flex}>
          <Button
            title={schedule === 'now' ? 'Request wash' : 'Schedule wash'}
            icon="car-wash"
            loading={placing}
            onPress={onRequest}
          />
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  flex: { flex: 1 },
  content: { gap: 0 },
  hero: {
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.xl,
    borderBottomLeftRadius: radius.xl,
    borderBottomRightRadius: radius.xl,
    gap: 4,
  },
  heroHello: { color: 'rgba(255,255,255,0.85)', fontSize: fontSize.body, fontWeight: fontWeight.medium },
  heroTitle: { color: '#fff', fontSize: fontSize.title, fontWeight: fontWeight.bold, marginBottom: spacing.sm },
  tenantBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    alignSelf: 'flex-start',
    marginBottom: 6,
  },
  tenantBadgeText: { color: '#fff', fontSize: fontSize.caption, fontWeight: fontWeight.bold, maxWidth: 200 },
  heroBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignSelf: 'flex-start',
    paddingHorizontal: spacing.sm,
    paddingVertical: 6,
    borderRadius: radius.pill,
    maxWidth: '100%',
  },
  heroBadgeText: { color: '#fff', fontSize: fontSize.caption, fontWeight: fontWeight.medium, flexShrink: 1 },
  body: { padding: spacing.md, gap: spacing.sm },
  sectionHead: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  sectionTitle: { fontSize: fontSize.section, fontWeight: fontWeight.semibold, color: colors.text },
  detectBtn: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  detectText: { color: colors.primary, fontWeight: fontWeight.semibold, fontSize: fontSize.caption },
  addressRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: spacing.xs },
  address: { color: colors.text, fontSize: fontSize.caption, fontWeight: fontWeight.medium, flex: 1 },
  tapHint: { color: colors.textMuted, fontSize: 11 },
  washList: { gap: spacing.sm },
  segment: {
    flexDirection: 'row',
    backgroundColor: colors.surfaceAlt,
    borderRadius: radius.md,
    padding: 4,
    gap: 4,
  },
  segmentItem: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    height: 44,
    borderRadius: radius.sm,
  },
  segmentItemActive: { backgroundColor: colors.primary },
  segmentText: { fontSize: fontSize.caption, fontWeight: fontWeight.semibold, color: colors.textSubtle },
  segmentTextActive: { color: colors.textOnPrimary },
  footer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingHorizontal: spacing.md,
    paddingTop: spacing.sm,
    backgroundColor: colors.surface,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    ...shadow.floating,
  },
  summary: { minWidth: 90 },
  summaryLabel: { fontSize: 11, color: colors.textMuted },
  summaryPrice: { fontSize: fontSize.bodyLg, fontWeight: fontWeight.bold, color: colors.primaryDark },
});
