// Powered by OnSpace.AI
import { AlertProvider } from '@/template';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Stack, useRouter, useSegments } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useEffect } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { AuthProvider } from '@/contexts/AuthContext';
import { TenantProvider, useTenant } from '@/contexts/TenantContext';
import { OrderProvider } from '@/contexts/OrderContext';
import { useAuth } from '@/hooks/useAuth';
import { colors } from '@/constants/theme';

function RootNavigator() {
  const { user, initializing } = useAuth();
  const { mode, selectedTenant, loading: tenantLoading } = useTenant();
  const segments = useSegments();
  const router = useRouter();

  useEffect(() => {
    if (initializing || (user && tenantLoading)) return;

    const inAuthFlow = segments[0] === '(auth)' || segments[0] === 'onboarding';

    if (!user) {
      if (!inAuthFlow) router.replace('/onboarding');
      return;
    }

    // Signed in — route to the right "mode" for this user.
    if (mode.kind === 'admin') {
      if (segments[0] !== '(admin)') router.replace('/(admin)/dashboard');
      return;
    }
    if (mode.kind === 'worker') {
      if (segments[0] !== '(worker)') router.replace('/(worker)/jobs');
      return;
    }

    // Customer: must pick a tenant before ordering.
    if (!selectedTenant) {
      if (segments[0] !== 'tenant-select') router.replace('/tenant-select');
      return;
    }
    if (inAuthFlow || segments[0] === 'tenant-select') {
      router.replace('/(tabs)');
    }
  }, [user, initializing, mode, selectedTenant, tenantLoading, segments, router]);

  if (initializing || (user && tenantLoading)) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background }}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return <Stack screenOptions={{ headerShown: false }} />;
}

export default function RootLayout() {
  return (
    <AlertProvider>
      <SafeAreaProvider>
        <AuthProvider>
          <TenantProvider>
            <OrderProvider>
              <StatusBar style="dark" />
              <RootNavigator />
            </OrderProvider>
          </TenantProvider>
        </AuthProvider>
      </SafeAreaProvider>
    </AlertProvider>
  );
}
