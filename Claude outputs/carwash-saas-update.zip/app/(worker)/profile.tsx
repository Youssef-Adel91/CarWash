// Powered by OnSpace.AI
import React, { useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { useAuth } from '@/hooks/useAuth';
import { useTenant } from '@/contexts/TenantContext';
import { useAlert } from '@/template';
import { updateWorkerProfile } from '@/services/membershipService';
import { colors, spacing, fontSize, fontWeight } from '@/constants/theme';

export default function WorkerProfile() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { user, logout } = useAuth();
  const { activeMembership, refresh } = useTenant();
  const { showAlert } = useAlert();
  const [vehicle, setVehicle] = useState(activeMembership?.vehicle ?? '');
  const [saving, setSaving] = useState(false);

  const onSaveVehicle = async () => {
    if (!activeMembership) return;
    setSaving(true);
    await updateWorkerProfile(activeMembership.id, { vehicle });
    await refresh();
    setSaving(false);
  };

  const onLogout = () => {
    showAlert('Log out', 'Are you sure you want to log out?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Log out',
        style: 'destructive',
        onPress: async () => {
          await logout();
          router.replace('/onboarding');
        },
      },
    ]);
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{ padding: spacing.md, paddingTop: insets.top + spacing.md, gap: spacing.md }}
    >
      <Text style={styles.title}>Worker profile</Text>

      <Card style={styles.row}>
        <MaterialCommunityIcons name="account" size={28} color={colors.primaryDark} />
        <View style={styles.flex}>
          <Text style={styles.name}>{user?.fullName}</Text>
          <Text style={styles.detail}>{activeMembership?.tenantName}</Text>
        </View>
      </Card>

      <Card style={{ gap: spacing.sm }}>
        <Text style={styles.sectionTitle}>Vehicle</Text>
        <Input label="Vehicle" value={vehicle} onChangeText={setVehicle} placeholder="e.g. White Wash Van" icon="car" />
        <Button title="Save" onPress={onSaveVehicle} loading={saving} variant="secondary" />
      </Card>

      <Card style={styles.row}>
        <MaterialCommunityIcons name="star" size={22} color={colors.warning} />
        <Text style={styles.detail}>Rating: {activeMembership?.rating.toFixed(1) ?? '5.0'}</Text>
      </Card>

      <Button title="Log out" variant="secondary" icon="logout" onPress={onLogout} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  title: { fontSize: fontSize.title, fontWeight: fontWeight.bold, color: colors.text },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  flex: { flex: 1 },
  name: { fontSize: fontSize.bodyLg, fontWeight: fontWeight.semibold, color: colors.text },
  detail: { fontSize: fontSize.caption, color: colors.textSubtle, marginTop: 2 },
  sectionTitle: { fontSize: fontSize.section, fontWeight: fontWeight.semibold, color: colors.text },
});
