// Powered by OnSpace.AI
import React, { useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { useAuth } from '@/hooks/useAuth';
import { useTenant } from '@/contexts/TenantContext';
import { useAlert } from '@/template';
import { updateTenant } from '@/services/tenantService';
import { colors, spacing, fontSize, fontWeight } from '@/constants/theme';

export default function AdminSettings() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { logout } = useAuth();
  const { activeMembership, refresh } = useTenant();
  const { showAlert } = useAlert();
  const [name, setName] = useState(activeMembership?.tenantName ?? '');
  const [saving, setSaving] = useState(false);

  const onSave = async () => {
    if (!activeMembership) return;
    setSaving(true);
    await updateTenant(activeMembership.tenantId, { name: name.trim() });
    await refresh();
    setSaving(false);
  };

  const onLogout = () => {
    showAlert('Log out', 'Are you sure you want to log out?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Log out',
        style: 'destructive',
        onPress: async () => {
          await logout();
          router.replace('/onboarding');
        },
      },
    ]);
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{ padding: spacing.md, paddingTop: insets.top + spacing.md, gap: spacing.md }}
    >
      <Text style={styles.title}>Business settings</Text>

      <Card style={{ gap: spacing.sm }}>
        <Input label="Business name" value={name} onChangeText={setName} icon="store-outline" />
        <Button title="Save" onPress={onSave} loading={saving} variant="secondary" />
      </Card>

      <Card style={styles.row}>
        <MaterialCommunityIcons name="account-badge-outline" size={22} color={colors.primaryDark} />
        <Text style={styles.detail}>Your role: {activeMembership?.role}</Text>
      </Card>

      <Button title="Log out" variant="secondary" icon="logout" onPress={onLogout} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  title: { fontSize: fontSize.title, fontWeight: fontWeight.bold, color: colors.text },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  detail: { fontSize: fontSize.body, color: colors.text },
});
