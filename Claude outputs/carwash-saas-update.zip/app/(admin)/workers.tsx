// Powered by OnSpace.AI
import React, { useCallback, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { useTenant } from '@/contexts/TenantContext';
import { useAlert } from '@/template';
import { addMemberByEmail, listMembers, removeMember } from '@/services/membershipService';
import { colors, spacing, radius, fontSize, fontWeight } from '@/constants/theme';
import type { TenantMembership } from '@/services/types';

export default function AdminWorkers() {
  const insets = useSafeAreaInsets();
  const { activeMembership } = useTenant();
  const { showAlert } = useAlert();
  const [members, setMembers] = useState<TenantMembership[]>([]);
  const [email, setEmail] = useState('');
  const [adding, setAdding] = useState(false);

  const load = useCallback(async () => {
    if (!activeMembership) return;
    setMembers(await listMembers(activeMembership.tenantId, 'worker'));
  }, [activeMembership]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load]),
  );

  const onAdd = async () => {
    if (!activeMembership || !email.trim()) return;
    setAdding(true);
    const result = await addMemberByEmail({ tenantId: activeMembership.tenantId, email: email.trim(), role: 'worker' });
    setAdding(false);
    if (!result.success) {
      showAlert('Could not add worker', result.error);
      return;
    }
    setEmail('');
    load();
  };

  const onRemove = (member: TenantMembership) => {
    showAlert('Remove worker', `Remove this worker from your team?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: async () => {
          await removeMember(member.id);
          load();
        },
      },
    ]);
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top + spacing.md }]}>
      <Text style={styles.title}>Workers</Text>

      <Card style={styles.addCard}>
        <Text style={styles.sectionTitle}>Add a worker</Text>
        <Text style={styles.hint}>They must already have a {`SplashGo`} account (any role) with this email.</Text>
        <View style={styles.addRow}>
          <View style={styles.flex}>
            <Input label="Email" value={email} onChangeText={setEmail} placeholder="worker@example.com" keyboardType="email-address" />
          </View>
        </View>
        <Button title="Add worker" icon="account-plus-outline" loading={adding} onPress={onAdd} />
      </Card>

      <FlatList
        data={members}
        keyExtractor={(m) => m.id}
        contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + spacing.xl }]}
        renderItem={({ item }) => (
          <Card style={styles.memberCard}>
            <View style={[styles.dot, { backgroundColor: item.isOnline ? colors.success : colors.textMuted }]} />
            <View style={styles.flex}>
              <Text style={styles.memberVehicle}>{item.vehicle || 'No vehicle set'}</Text>
              <Text style={styles.memberMeta}>Rating {item.rating.toFixed(1)} · {item.isOnline ? 'Online' : 'Offline'}</Text>
            </View>
            <Pressable onPress={() => onRemove(item)} hitSlop={8}>
              <MaterialCommunityIcons name="account-remove-outline" size={20} color={colors.danger} />
            </Pressable>
          </Card>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, paddingHorizontal: spacing.md },
  title: { fontSize: fontSize.title, fontWeight: fontWeight.bold, color: colors.text, marginBottom: spacing.md },
  addCard: { gap: spacing.sm, marginBottom: spacing.md },
  sectionTitle: { fontSize: fontSize.section, fontWeight: fontWeight.semibold, color: colors.text },
  hint: { fontSize: fontSize.caption, color: colors.textMuted },
  addRow: { flexDirection: 'row', gap: spacing.sm },
  flex: { flex: 1 },
  list: { gap: spacing.sm },
  memberCard: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  dot: { width: 10, height: 10, borderRadius: 5 },
  memberVehicle: { fontSize: fontSize.body, fontWeight: fontWeight.medium, color: colors.text },
  memberMeta: { fontSize: fontSize.caption, color: colors.textSubtle, marginTop: 2 },
});
