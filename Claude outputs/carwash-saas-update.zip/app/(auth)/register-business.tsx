// Powered by OnSpace.AI
// Business (tenant) sign-up: same account + onboarding-fee flow as
// customer registration, plus creating the tenant row that makes this
// user an 'owner' who lands in the admin dashboard afterwards.
import React, { useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { PaymobCheckoutSheet } from '@/components/feature/PaymobCheckoutSheet';
import { useAuth } from '@/hooks/useAuth';
import { useTenant } from '@/contexts/TenantContext';
import { useAlert } from '@/template';
import { validateCard } from '@/services/paymentService';
import { subscribeToPaymentStatus } from '@/services/paymentGateway';
import { createTenant } from '@/services/tenantService';
import { colors, spacing, fontSize, fontWeight } from '@/constants/theme';
import { APP_CONFIG } from '@/constants/config';

type Step = 'details' | 'verify';

export default function RegisterBusiness() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { sendRegistrationOtp, completeRegistration, chargeRegistrationFee } = useAuth();
  const { refresh: refreshTenantMode } = useTenant();
  const { showAlert } = useAlert();

  const [step, setStep] = useState<Step>('details');
  const [businessName, setBusinessName] = useState('');
  const [city, setCity] = useState('');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvc, setCvc] = useState('');
  const [cardName, setCardName] = useState('');
  const [otp, setOtp] = useState('');
  const [sending, setSending] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [checkoutUrl, setCheckoutUrl] = useState<string | null>(null);

  const isMock = APP_CONFIG.paymentProvider === 'mock';
  const card = { number: cardNumber, expiry, cvc, name: cardName };

  const onSendCode = async () => {
    if (!businessName || !fullName || !email || !phone || !password) {
      showAlert('Missing details', 'Please complete all fields.');
      return;
    }
    if (password.length < 6) {
      showAlert('Weak password', 'Password must be at least 6 characters.');
      return;
    }
    if (isMock) {
      const cardError = validateCard(card);
      if (cardError) {
        showAlert('Check your card', cardError);
        return;
      }
    }
    setSending(true);
    const { error } = await sendRegistrationOtp(email.trim());
    setSending(false);
    if (error) {
      showAlert('Could not send code', error);
      return;
    }
    setStep('verify');
  };

  const finishAsOwner = async (ownerId: string) => {
    try {
      await createTenant({ ownerId, name: businessName.trim(), city: city.trim() || undefined });
    } catch (e) {
      showAlert('Business could not be created', (e as Error).message);
      router.replace('/onboarding');
      return;
    }
    await refreshTenantMode();
    showAlert('Business created', `${businessName.trim()} is live on ${APP_CONFIG.name}.`, [
      { text: 'Go to dashboard', onPress: () => router.replace('/(admin)/dashboard') },
    ]);
  };

  const onVerify = async () => {
    if (otp.trim().length < 4) {
      showAlert('Enter the code', 'Please enter the verification code from your email.');
      return;
    }
    setVerifying(true);
    const result = await completeRegistration({
      fullName: fullName.trim(),
      email: email.trim(),
      phone: phone.trim(),
      password,
      otp: otp.trim(),
    });
    if (!result.success) {
      setVerifying(false);
      showAlert('Could not create account', result.error);
      return;
    }

    const charge = await chargeRegistrationFee(isMock ? card : undefined);
    setVerifying(false);
    if (!charge.success) {
      showAlert('Account created, but the fee failed', charge.error);
      await finishAsOwner(result.user.id);
      return;
    }
    if (charge.mode === 'instant') {
      await finishAsOwner(result.user.id);
      return;
    }
    setCheckoutUrl(charge.checkoutUrl);
    const unsubscribe = subscribeToPaymentStatus(charge.paymentId, async (status) => {
      unsubscribe();
      setCheckoutUrl(null);
      if (status === 'succeeded') await finishAsOwner(result.user.id);
      else showAlert('Payment failed', 'The onboarding fee could not be charged.');
    });
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.flex}>
      <PaymobCheckoutSheet visible={!!checkoutUrl} checkoutUrl={checkoutUrl} onClose={() => setCheckoutUrl(null)} />
      <ScrollView
        style={styles.flex}
        contentContainerStyle={[styles.content, { paddingTop: insets.top + spacing.lg, paddingBottom: insets.bottom + spacing.xl }]}
        keyboardShouldPersistTaps="handled"
      >
        <Pressable onPress={() => (step === 'verify' ? setStep('details') : router.back())} style={styles.back} hitSlop={12}>
          <MaterialCommunityIcons name="arrow-left" size={24} color={colors.text} />
        </Pressable>

        {step === 'details' ? (
          <>
            <View style={styles.iconWrap}>
              <MaterialCommunityIcons name="store-plus-outline" size={34} color={colors.primary} />
            </View>
            <Text style={styles.title}>List your car wash</Text>
            <Text style={styles.subtitle}>Create your business + owner account in one step.</Text>

            <View style={styles.form}>
              <Input label="Business name" value={businessName} onChangeText={setBusinessName} placeholder="e.g. Cairo Sparkle Wash" autoCapitalize="words" icon="store-outline" />
              <Input label="City" value={city} onChangeText={setCity} placeholder="Cairo" autoCapitalize="words" icon="map-marker-outline" />
              <Input label="Your full name" value={fullName} onChangeText={setFullName} placeholder="Owner name" autoCapitalize="words" icon="account-outline" />
              <Input label="Email" value={email} onChangeText={setEmail} placeholder="you@example.com" keyboardType="email-address" icon="email-outline" />
              <Input label="Phone" value={phone} onChangeText={setPhone} placeholder="01xxxxxxxxx" keyboardType="phone-pad" icon="phone-outline" />
              <Input label="Password" value={password} onChangeText={setPassword} placeholder="At least 6 characters" secureTextEntry icon="lock-outline" />
            </View>

            {isMock ? (
              <>
                <Text style={styles.sectionLabel}>Payment card (Visa)</Text>
                <View style={styles.form}>
                  <Input label="Card number" value={cardNumber} onChangeText={setCardNumber} placeholder="4242 4242 4242 4242" keyboardType="number-pad" icon="credit-card-outline" maxLength={19} />
                  <View style={styles.cardRow}>
                    <View style={styles.flex}>
                      <Input label="Expiry" value={expiry} onChangeText={setExpiry} placeholder="MM/YY" keyboardType="number-pad" maxLength={5} />
                    </View>
                    <View style={styles.flex}>
                      <Input label="CVC" value={cvc} onChangeText={setCvc} placeholder="123" keyboardType="number-pad" maxLength={4} />
                    </View>
                  </View>
                  <Input label="Cardholder name" value={cardName} onChangeText={setCardName} placeholder="Name on card" autoCapitalize="words" icon="account-box-outline" />
                </View>
              </>
            ) : null}

            <Button title="Send verification code" icon="email-fast-outline" loading={sending} onPress={onSendCode} style={{ marginTop: spacing.sm }} />
          </>
        ) : (
          <>
            <Text style={styles.title}>Verify your email</Text>
            <Text style={styles.subtitle}>Enter the code we sent to {email.trim()}.</Text>
            <View style={styles.form}>
              <Input label="Verification code" value={otp} onChangeText={setOtp} placeholder="1234" keyboardType="number-pad" icon="shield-key-outline" maxLength={6} />
            </View>
            <Button
              title={`Verify & pay ${APP_CONFIG.registrationFee} ${APP_CONFIG.currency}`}
              icon="credit-card-check-outline"
              loading={verifying}
              onPress={onVerify}
              style={{ marginTop: spacing.sm }}
            />
          </>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: colors.background },
  content: { paddingHorizontal: spacing.lg, gap: spacing.md },
  back: { alignSelf: 'flex-start' },
  iconWrap: {
    width: 64,
    height: 64,
    borderRadius: 20,
    backgroundColor: colors.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: spacing.sm,
  },
  title: { fontSize: fontSize.title, fontWeight: fontWeight.bold, color: colors.text, marginTop: spacing.xs },
  subtitle: { fontSize: fontSize.body, color: colors.textSubtle, marginTop: -spacing.xs },
  form: { gap: spacing.md },
  cardRow: { flexDirection: 'row', gap: spacing.md },
  sectionLabel: { fontSize: fontSize.section, fontWeight: fontWeight.semibold, color: colors.text },
});
