// Powered by OnSpace.AI
import React, { useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { PaymobCheckoutSheet } from '@/components/feature/PaymobCheckoutSheet';
import { useAuth } from '@/hooks/useAuth';
import { useAlert } from '@/template';
import { validateCard } from '@/services/paymentService';
import { subscribeToPaymentStatus } from '@/services/paymentGateway';
import { colors, spacing, fontSize, fontWeight } from '@/constants/theme';
import { APP_CONFIG } from '@/constants/config';

type Step = 'details' | 'verify';

export default function Register() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { sendRegistrationOtp, completeRegistration, chargeRegistrationFee } = useAuth();
  const { showAlert } = useAlert();

  const [step, setStep] = useState<Step>('details');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvc, setCvc] = useState('');
  const [cardName, setCardName] = useState('');
  const [otp, setOtp] = useState('');
  const [sending, setSending] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [checkoutUrl, setCheckoutUrl] = useState<string | null>(null);

  const isMock = APP_CONFIG.paymentProvider === 'mock';
  const card = { number: cardNumber, expiry, cvc, name: cardName };
  const cardLast4 = cardNumber.replace(/\s+/g, '').slice(-4) || '____';

  const onSendCode = async () => {
    if (!fullName || !email || !phone || !password) {
      showAlert('Missing details', 'Please complete all account fields.');
      return;
    }
    if (password.length < 6) {
      showAlert('Weak password', 'Password must be at least 6 characters.');
      return;
    }
    if (isMock) {
      const cardError = validateCard(card);
      if (cardError) {
        showAlert('Check your card', cardError);
        return;
      }
    }
    setSending(true);
    const { error } = await sendRegistrationOtp(email.trim());
    setSending(false);
    if (error) {
      showAlert('Could not send code', error);
      return;
    }
    setStep('verify');
    showAlert('Verification code sent', `We emailed a code to ${email.trim()}. Enter it below to finish.`);
  };

  const finishAfterPayment = () => {
    showAlert(
      'Account created',
      `A ${APP_CONFIG.registrationFee} ${APP_CONFIG.currency} onboarding fee was charged to your card.`,
      [{ text: 'Get started', onPress: () => router.replace('/tenant-select') }],
    );
  };

  const onVerify = async () => {
    if (otp.trim().length < 4) {
      showAlert('Enter the code', 'Please enter the verification code from your email.');
      return;
    }
    setVerifying(true);
    const result = await completeRegistration({
      fullName: fullName.trim(),
      email: email.trim(),
      phone: phone.trim(),
      password,
      otp: otp.trim(),
    });
    if (!result.success) {
      setVerifying(false);
      showAlert('Could not create account', result.error);
      return;
    }

    const charge = await chargeRegistrationFee(isMock ? card : undefined);
    setVerifying(false);
    if (!charge.success) {
      showAlert('Account created, but the fee failed', charge.error);
      router.replace('/tenant-select');
      return;
    }
    if (charge.mode === 'instant') {
      finishAfterPayment();
      return;
    }
    // Paymob checkout mode: show the hosted card page, then wait for the
    // webhook to flip the payment row (subscribeToPaymentStatus below).
    setCheckoutUrl(charge.checkoutUrl);
    const unsubscribe = subscribeToPaymentStatus(charge.paymentId, (status) => {
      unsubscribe();
      setCheckoutUrl(null);
      if (status === 'succeeded') finishAfterPayment();
      else showAlert('Payment failed', 'The onboarding fee could not be charged. You can retry it from your profile.');
    });
  };

  const onResend = async () => {
    setSending(true);
    const { error } = await sendRegistrationOtp(email.trim());
    setSending(false);
    showAlert(
      error ? 'Could not resend' : 'Code resent',
      error ?? `A new code was sent to ${email.trim()}.`,
    );
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.flex}
    >
      <PaymobCheckoutSheet visible={!!checkoutUrl} checkoutUrl={checkoutUrl} onClose={() => setCheckoutUrl(null)} />
      <ScrollView
        style={styles.flex}
        contentContainerStyle={[
          styles.content,
          { paddingTop: insets.top + spacing.lg, paddingBottom: insets.bottom + spacing.xl },
        ]}
        keyboardShouldPersistTaps="handled"
      >
        <Pressable
          onPress={() => (step === 'verify' ? setStep('details') : router.back())}
          style={styles.back}
          hitSlop={12}
        >
          <MaterialCommunityIcons name="arrow-left" size={24} color={colors.text} />
        </Pressable>

        {step === 'details' ? (
          <>
            <Text style={styles.title}>Create your account</Text>
            <Text style={styles.subtitle}>Join {APP_CONFIG.name} and book washes on demand.</Text>

            <View style={styles.form}>
              <Input label="Full name" value={fullName} onChangeText={setFullName} placeholder="Your name" autoCapitalize="words" icon="account-outline" />
              <Input label="Email" value={email} onChangeText={setEmail} placeholder="you@example.com" keyboardType="email-address" icon="email-outline" />
              <Input label="Phone" value={phone} onChangeText={setPhone} placeholder="01xxxxxxxxx" keyboardType="phone-pad" icon="phone-outline" />
              <Input label="Password" value={password} onChangeText={setPassword} placeholder="At least 6 characters" secureTextEntry icon="lock-outline" />
            </View>

            <View style={styles.feeBanner}>
              <MaterialCommunityIcons name="shield-check" size={22} color={colors.primaryDark} />
              <View style={styles.flex}>
                <Text style={styles.feeTitle}>
                  One-time onboarding fee: {APP_CONFIG.registrationFee} {APP_CONFIG.currency}
                </Text>
                <Text style={styles.feeText}>
                  {isMock
                    ? 'Charged to your Visa card after email verification (simulated in demo mode).'
                    : "You'll enter your Visa/Mastercard details on a secure Paymob page after verification."}
                </Text>
              </View>
            </View>

            {isMock ? (
              <>
                <Text style={styles.sectionLabel}>Payment card (Visa)</Text>
                <View style={styles.form}>
                  <Input label="Card number" value={cardNumber} onChangeText={setCardNumber} placeholder="4242 4242 4242 4242" keyboardType="number-pad" icon="credit-card-outline" maxLength={19} />
                  <View style={styles.cardRow}>
                    <View style={styles.flex}>
                      <Input label="Expiry" value={expiry} onChangeText={setExpiry} placeholder="MM/YY" keyboardType="number-pad" maxLength={5} />
                    </View>
                    <View style={styles.flex}>
                      <Input label="CVC" value={cvc} onChangeText={setCvc} placeholder="123" keyboardType="number-pad" maxLength={4} />
                    </View>
                  </View>
                  <Input label="Cardholder name" value={cardName} onChangeText={setCardName} placeholder="Name on card" autoCapitalize="words" icon="account-box-outline" />
                </View>
              </>
            ) : null}

            <Button
              title="Send verification code"
              icon="email-fast-outline"
              loading={sending}
              onPress={onSendCode}
              style={{ marginTop: spacing.sm }}
            />
          </>
        ) : (
          <>
            <View style={styles.iconWrap}>
              <MaterialCommunityIcons name="email-check-outline" size={34} color={colors.primary} />
            </View>
            <Text style={styles.title}>Verify your email</Text>
            <Text style={styles.subtitle}>Enter the code we sent to {email.trim()}.</Text>

            <View style={styles.form}>
              <Input
                label="Verification code"
                value={otp}
                onChangeText={setOtp}
                placeholder="1234"
                keyboardType="number-pad"
                icon="shield-key-outline"
                maxLength={6}
              />
            </View>

            <View style={styles.feeBanner}>
              <MaterialCommunityIcons name="credit-card-check-outline" size={22} color={colors.primaryDark} />
              <View style={styles.flex}>
                <Text style={styles.feeTitle}>
                  {APP_CONFIG.registrationFee} {APP_CONFIG.currency} onboarding fee
                </Text>
                <Text style={styles.feeText}>
                  {isMock
                    ? `Charged to your Visa •••• ${cardLast4} once verified (simulated).`
                    : 'A secure Paymob card page will open once verified.'}
                </Text>
              </View>
            </View>

            <Button
              title={`Verify & pay ${APP_CONFIG.registrationFee} ${APP_CONFIG.currency}`}
              icon="credit-card-check-outline"
              loading={verifying}
              onPress={onVerify}
              style={{ marginTop: spacing.sm }}
            />
            <Pressable onPress={onResend} disabled={sending} hitSlop={8} style={styles.resend}>
              <Text style={styles.resendText}>{sending ? 'Sending…' : 'Resend code'}</Text>
            </Pressable>
          </>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: colors.background },
  content: { paddingHorizontal: spacing.lg, gap: spacing.md },
  back: { alignSelf: 'flex-start' },
  iconWrap: {
    width: 64,
    height: 64,
    borderRadius: 20,
    backgroundColor: colors.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: spacing.sm,
  },
  title: { fontSize: fontSize.title, fontWeight: fontWeight.bold, color: colors.text, marginTop: spacing.xs },
  subtitle: { fontSize: fontSize.body, color: colors.textSubtle, marginTop: -spacing.xs },
  form: { gap: spacing.md },
  cardRow: { flexDirection: 'row', gap: spacing.md },
  feeBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: colors.primaryLight,
    padding: spacing.md,
    borderRadius: 14,
  },
  feeTitle: { fontSize: fontSize.body, fontWeight: fontWeight.semibold, color: colors.primaryDark },
  feeText: { fontSize: fontSize.caption, color: colors.primaryDark, marginTop: 2, lineHeight: 18 },
  sectionLabel: { fontSize: fontSize.section, fontWeight: fontWeight.semibold, color: colors.text },
  resend: { alignSelf: 'center', paddingVertical: spacing.sm },
  resendText: { color: colors.primary, fontWeight: fontWeight.semibold, fontSize: fontSize.body },
});
