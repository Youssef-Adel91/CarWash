// Powered by OnSpace.AI
// App-wide configuration constants.

export const APP_CONFIG = {
  name: 'SplashGo',
  currency: 'EGP',
  registrationFee: 10, // Default 10 EGP onboarding fee; a tenant can override its own (tenants.registration_fee_egp).
  defaultLocation: {
    latitude: 30.0444,
    longitude: 31.2357,
    address: 'Downtown, Cairo',
  },
  // Simulated timings (ms) for the mocked order lifecycle. Only used while
  // no real worker has accepted the order yet — once accepted, status
  // changes come from the worker app in real time.
  mockTimings: {
    findWorker: 3000,
  },
  // 'mock'   → instant simulated Visa charge (default, safe for demos/dev)
  // 'paymob' → real Paymob checkout — see services/paymentGateway/paymobGateway.ts
  //            and supabase/functions/*. Flip this once your edge functions
  //            and Paymob merchant credentials are live.
  paymentProvider: 'mock' as 'mock' | 'paymob',
} as const;
